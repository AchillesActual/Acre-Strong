// Main JavaScript for Acre Strong

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuButton = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuButton) {
        mobileMenuButton.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            mobileMenuButton.classList.toggle('active');
        });
    }

    // Lease Value Calculator
    const calculatorForm = document.getElementById('lease-calculator');
    if (calculatorForm) {
        calculatorForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const acres = parseFloat(document.getElementById('calc-acres').value);
            const projectType = document.getElementById('calc-project-type').value;
            const duration = parseInt(document.getElementById('calc-duration').value);
            
            let baseRate = projectType === 'solar' ? 1000 : 500; // Example base rates
            let annualValue = acres * baseRate;
            let totalValue = annualValue * duration;
            
            document.getElementById('calc-result').innerHTML = `
                <h3>Estimated Lease Value</h3>
                <p>Annual Value: $${annualValue.toLocaleString()}</p>
                <p>Total ${duration}-Year Value: $${totalValue.toLocaleString()}</p>
                <small>* This is a rough estimate. Contact us for a detailed analysis.</small>
            `;
        });
    }

    // Smooth Scroll for Anchor Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Form Validation
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Basic validation
            let isValid = true;
            const requiredFields = contactForm.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('error');
                } else {
                    field.classList.remove('error');
                }
            });
            
            if (isValid) {
                // Here you would typically send the form data to your server
                const formData = new FormData(contactForm);
                console.log('Form submitted:', Object.fromEntries(formData));
                
                // Show success message
                const successMessage = document.createElement('div');
                successMessage.className = 'success-message';
                successMessage.textContent = 'Thank you! We will contact you soon.';
                contactForm.appendChild(successMessage);
                
                // Reset form
                contactForm.reset();
            }
        });
    }

    // News Article Filter
    const newsFilter = document.querySelector('.news-filter');
    if (newsFilter) {
        newsFilter.addEventListener('change', function(e) {
            const category = e.target.value;
            const articles = document.querySelectorAll('.news-card');
            
            articles.forEach(article => {
                if (category === 'all' || article.dataset.category === category) {
                    article.style.display = 'block';
                } else {
                    article.style.display = 'none';
                }
            });
        });
    }

    // Testimonials Slider
    let currentTestimonial = 0;
    const testimonials = document.querySelectorAll('.testimonial-card');
    const totalTestimonials = testimonials.length;

    function showTestimonial(index) {
        testimonials.forEach(t => t.style.display = 'none');
        testimonials[index].style.display = 'block';
    }

    if (testimonials.length > 0) {
        // Show first testimonial initially
        showTestimonial(0);

        // Set up auto-rotation
        setInterval(() => {
            currentTestimonial = (currentTestimonial + 1) % totalTestimonials;
            showTestimonial(currentTestimonial);
        }, 5000);
    }

    // Intersection Observer for Fade-In Animations
    const fadeElements = document.querySelectorAll('.fade-in');
    
    const fadeObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, {
        threshold: 0.1
    });

    fadeElements.forEach(element => {
        fadeObserver.observe(element);
    });
});

// Resource Download Tracking
function trackDownload(resourceId) {
    // Here you would typically send analytics data to your server
    console.log(`Resource downloaded: ${resourceId}`);
}

// Newsletter Subscription
function subscribeNewsletter(email) {
    // Here you would typically handle newsletter subscription
    console.log(`Newsletter subscription: ${email}`);
    return new Promise((resolve, reject) => {
        // Simulate API call
        setTimeout(() => {
            if (email.includes('@')) {
                resolve('Successfully subscribed!');
            } else {
                reject('Invalid email address');
            }
        }, 1000);
    });
}

// Map Initialization (assuming using a mapping service)
function initMap() {
    // Here you would typically initialize your map
    console.log('Map initialized');
}

// Export any functions that need to be accessed globally
window.trackDownload = trackDownload;
window.subscribeNewsletter = subscribeNewsletter;
window.initMap = initMap;